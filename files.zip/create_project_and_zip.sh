#!/usr/bin/env bash
# Creates the demo Spring Boot project files and packages them into demo-springboot-app.zip
# Usage: ./create_project_and_zip.sh
set -euo pipefail

ROOT_DIR="demo-springboot-app"
ZIP_NAME="demo-springboot-app.zip"

# Clean up previous run
rm -rf "$ROOT_DIR" "$ZIP_NAME"

# Create directories
mkdir -p "$ROOT_DIR"/{src/main/java/com/example/demo,src/main/java/com/example/demo/controller,src/main/java/com/example/demo/dto,src/main/java/com/example/demo/entity,src/main/java/com/example/demo/repository,src/main/java/com/example/demo/service,src/main/resources,src/test/java/com/example/demo}

# Write pom.xml
cat > "$ROOT_DIR/pom.xml" <<'EOF'
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
           http://maven.apache.org/maven-v4_0_0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <groupId>com.example</groupId>
  <artifactId>demo-springboot-app</artifactId>
  <version>0.0.1-SNAPSHOT</version>
  <packaging>jar</packaging>

  <name>demo-springboot-app</name>

  <properties>
    <java.version>17</java.version>
    <spring.boot.version>3.1.6</spring.boot.version>
    <maven.compiler.source>${java.version}</maven.compiler.source>
    <maven.compiler.target>${java.version}</maven.compiler.target>
  </properties>

  <dependencyManagement>
    <dependencies>
      <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-dependencies</artifactId>
        <version>${spring.boot.version}</version>
        <type>pom</type>
        <scope>import</scope>
      </dependency>
    </dependencies>
  </dependencyManagement>

  <dependencies>
    <!-- Web -->
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <!-- JPA -->
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>

    <!-- H2 (in-memory DB for sample) -->
    <dependency>
      <groupId>com.h2database</groupId>
      <artifactId>h2</artifactId>
      <scope>runtime</scope>
    </dependency>

    <!-- Jakarta persistence API (if needed by some environments) -->
    <dependency>
      <groupId>jakarta.persistence</groupId>
      <artifactId>jakarta.persistence-api</artifactId>
      <version>3.1.0</version>
    </dependency>

    <!-- Tests -->
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-test</artifactId>
      <scope>test</scope>
    </dependency>
  </dependencies>

  <build>
    <plugins>
      <plugin>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-maven-plugin</artifactId>
        <configuration>
          <mainClass>com.example.demo.DemoApplication</mainClass>
        </configuration>
      </plugin>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-compiler-plugin</artifactId>
        <version>3.10.1</version>
        <configuration>
          <source>${java.version}</source>
          <target>${java.version}</target>
        </configuration>
      </plugin>
    </plugins>
  </build>
</project>
EOF

# Write DemoApplication.java
cat > "$ROOT_DIR/src/main/java/com/example/demo/DemoApplication.java" <<'EOF'
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {
  public static void main(String[] args) {
    SpringApplication.run(DemoApplication.class, args);
  }
}
EOF

# Write Person entity
cat > "$ROOT_DIR/src/main/java/com/example/demo/entity/Person.java" <<'EOF'
package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "persons")
public class Person {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(unique = true)
    private String email;

    public Person() {}

    public Person(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    // getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}
EOF

# Write PersonDTO.java
cat > "$ROOT_DIR/src/main/java/com/example/demo/dto/PersonDTO.java" <<'EOF'
package com.example.demo.dto;

public class PersonDTO {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;

    public PersonDTO() {}

    public PersonDTO(Long id, String firstName, String lastName, String email) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    // getters/setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}
EOF

# Write repository
cat > "$ROOT_DIR/src/main/java/com/example/demo/repository/PersonRepository.java" <<'EOF'
package com.example.demo.repository;

import com.example.demo.entity.Person;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PersonRepository extends JpaRepository<Person, Long> {
    Optional<Person> findByEmail(String email);
}
EOF

# Write service
cat > "$ROOT_DIR/src/main/java/com/example/demo/service/PersonService.java" <<'EOF'
package com.example.demo.service;

import com.example.demo.dto.PersonDTO;
import com.example.demo.entity.Person;
import com.example.demo.repository.PersonRepository;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class PersonService {

    private final PersonRepository repository;

    public PersonService(PersonRepository repository) {
        this.repository = repository;
    }

    private PersonDTO toDTO(Person p) {
        return new PersonDTO(p.getId(), p.getFirstName(), p.getLastName(), p.getEmail());
    }

    private Person fromDTO(PersonDTO dto) {
        Person p = new Person();
        p.setFirstName(dto.getFirstName());
        p.setLastName(dto.getLastName());
        p.setEmail(dto.getEmail());
        return p;
    }

    public List<PersonDTO> findAll() {
        return repository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public Optional<PersonDTO> findById(Long id) {
        return repository.findById(id).map(this::toDTO);
    }

    public PersonDTO create(PersonDTO dto) {
        Person p = fromDTO(dto);
        Person saved = repository.save(p);
        return toDTO(saved);
    }

    public Optional<PersonDTO> update(Long id, PersonDTO dto) {
        return repository.findById(id).map(existing -> {
            existing.setFirstName(dto.getFirstName());
            existing.setLastName(dto.getLastName());
            existing.setEmail(dto.getEmail());
            Person saved = repository.save(existing);
            return toDTO(saved);
        });
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
EOF

# Write controller
cat > "$ROOT_DIR/src/main/java/com/example/demo/controller/PersonController.java" <<'EOF'
package com.example.demo.controller;

import com.example.demo.dto.PersonDTO;
import com.example.demo.service.PersonService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/persons")
public class PersonController {

    private final PersonService service;

    public PersonController(PersonService service) {
        this.service = service;
    }

    @GetMapping
    public List<PersonDTO> list() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PersonDTO> get(@PathVariable Long id) {
        return service.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<PersonDTO> create(@RequestBody PersonDTO dto) {
        PersonDTO created = service.create(dto);
        return ResponseEntity.created(URI.create("/api/persons/" + created.getId())).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PersonDTO> update(@PathVariable Long id, @RequestBody PersonDTO dto) {
        return service.update(id, dto).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
EOF

# Write application.properties
cat > "$ROOT_DIR/src/main/resources/application.properties" <<'EOF'
spring.application.name=demo-springboot-app
server.port=8080

# H2 console (for local exploration)
spring.h2.console.enabled=true
spring.h2.console.path=/h2-console

# JPA / Hibernate
spring.datasource.url=jdbc:h2:mem:demo;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true

# Logging (optional)
logging.level.org.hibernate.SQL=DEBUG
logging.level.org.hibernate.type.descriptor.sql.BasicBinder=TRACE
EOF

# Write data.sql
cat > "$ROOT_DIR/src/main/resources/data.sql" <<'EOF'
INSERT INTO persons (id, first_name, last_name, email) VALUES (1, 'Ada', 'Lovelace', 'ada@example.com');
INSERT INTO persons (id, first_name, last_name, email) VALUES (2, 'Alan', 'Turing', 'alan@example.com');

-- Note: H2 identity generation may ignore provided id values depending on ddl-auto setting.
-- If you find primary key conflicts, remove id columns from these INSERTs to let the DB generate ids.
EOF

# Write test
cat > "$ROOT_DIR/src/test/java/com/example/demo/PersonServiceIntegrationTest.java" <<'EOF'
package com.example.demo;

import com.example.demo.dto.PersonDTO;
import com.example.demo.service.PersonService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class PersonServiceIntegrationTest {

    @Autowired
    PersonService service;

    @Test
    void createAndFind() {
        PersonDTO dto = new PersonDTO(null, "Grace", "Hopper", "grace@example.com");
        PersonDTO created = service.create(dto);
        assertThat(created.getId()).isNotNull();

        PersonDTO fetched = service.findById(created.getId()).orElseThrow();
        assertThat(fetched.getEmail()).isEqualTo("grace@example.com");

        service.delete(created.getId());
        assertThat(service.findById(created.getId())).isEmpty();
    }
}
EOF

# Write README.md
cat > "$ROOT_DIR/README.md" <<'EOF'
# Demo Spring Boot App (Expanded)

A small layered Spring Boot application demonstrating:
- DTOs
- Service layer
- JPA persistence with H2
- REST controller
- Sample data and tests

Requirements
- Java 17
- Maven

Build